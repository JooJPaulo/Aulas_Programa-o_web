const express = require('express');
const app = express();
const path = require('path');

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/notas', (req, res) => {
    
    const contador = req.query.contador;
    const nome = req.query.nome;
    const nota1 = parseFloat(req.query.nota1);
    const nota2 = parseFloat(req.query.nota2);
    const media = (nota1 + nota2) / 2;
    
    
    
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
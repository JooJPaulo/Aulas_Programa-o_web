const express = require('express');
const path = require('path');
const app = express();
const request = require('request');

app.use(express.static(path.join(__dirname, 'public')));
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/Aula 03', (req, res) => {
    const contador = parseInt(req.query.contador) = 0;
    const idade = parseInt(req.query.idade);
    
    

});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});